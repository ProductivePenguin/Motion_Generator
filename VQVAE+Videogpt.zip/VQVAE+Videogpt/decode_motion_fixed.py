import argparse
import os
import torch
import torch.nn.functional as F
from tqdm import tqdm
from train_motion_videogpt_fixed import MotionVideoGPT
from motion_vqvae import MotionVQVAE
from motion_dataset import MotionVectorDatasetNew

def sample_next_token(model, context, device, temperature=1.0, top_k=50):
    x_emb = model.vqvae.codebook.embeddings[context.to(model.vqvae.codebook.embeddings.device)]
    h = model.fc_in(x_emb)
    h = model.pos_enc(h)
    h = model.drop(h)
    h = model.transformer(h, mask=model.mask)
    logits = model.fc_out(h[:, -1, :]) / temperature
    if top_k > 0:
        vals, idx = torch.topk(logits, top_k, dim=-1)
        mask = torch.full_like(logits, float('-inf'))
        mask.scatter_(1, idx, vals)
        logits = mask
    probs = torch.softmax(logits, dim=-1)
    return torch.multinomial(probs, num_samples=1)

def autoregressive_generate_full(model, init_context, gen_tokens, device, temperature=1.0):
    context = init_context.to(device)
    generated = []
    model.eval()
    with torch.no_grad():
        for _ in range(gen_tokens):
            next_tok = sample_next_token(model, context, device, temperature)
            generated.append(next_tok.item())
            context = torch.cat([context, next_tok], dim=1)
            if context.size(1) > model.hparams.seq_len:
                context = context[:, -model.hparams.seq_len:]
    return torch.tensor(generated, dtype=torch.long).unsqueeze(0)

def decode_line_from_tokens(model, tokens, norm_factor):
    device = model.vqvae.codebook.embeddings.device
    tokens = tokens.to(device)
    quantized = F.embedding(tokens, model.vqvae.codebook.embeddings)
    quantized = quantized.transpose(1, 2).unsqueeze(2)
    pred = model.vqvae.output_proj(quantized)
    pred = pred * norm_factor
    arr = pred.detach().squeeze().cpu().numpy()
    return " ".join(str(int(round(x))) for x in arr)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gpt_checkpoint", required=True)
    parser.add_argument("--vqvae_checkpoint_override", required=True)
    parser.add_argument("--input_folder", required=True)
    parser.add_argument("--output_folder", required=True)
    parser.add_argument("--gen_frames", type=int, default=30)
    parser.add_argument("--norm_factor", type=float, default=10.0)
    parser.add_argument("--temperature", type=float, default=1.0)
    parser.add_argument("--top_k", type=int, default=50)
    parser.add_argument("--device", type=str, default="cuda")
    args = parser.parse_args()

    os.makedirs(args.output_folder, exist_ok=True)
    device = torch.device(args.device)

    gpt_model = MotionVideoGPT.load_from_checkpoint(
        args.gpt_checkpoint,
        vqvae_checkpoint_override=args.vqvae_checkpoint_override
    ).to(device).eval()

    vq_model = MotionVQVAE.load_from_checkpoint(args.vqvae_checkpoint_override)
    vq_model.to(device).eval()
    gpt_model.vqvae = vq_model

    dataset = MotionVectorDatasetNew(
        root_dir=args.input_folder,
        normalize=True,
        norm_factor=args.norm_factor
    )

    for sample in tqdm(dataset, desc="Processing files"):
        fname = sample["file"]
        mv = sample["mv"].to(device)
        out_lines = []

        for i in range(mv.size(1)):
            line = mv[:, i, :].unsqueeze(1).unsqueeze(2)
            with torch.no_grad():
                _, _, vq_out = vq_model(line)
            flat_tokens = vq_out["encodings"].view(1, -1)
            init_ctx = flat_tokens[:, -gpt_model.hparams.seq_len:]
            gen = autoregressive_generate_full(
                gpt_model, init_ctx,
                args.gen_frames, device,
                temperature=args.temperature
            )
            decoded = decode_line_from_tokens(gpt_model, gen, args.norm_factor)
            out_lines.append(decoded)

        out_path = os.path.join(
            args.output_folder,
            fname.replace(".txt", "_generated.txt")
        )
        with open(out_path, "w") as f:
            f.write("\n".join(out_lines))

    print("Generation complete.")

if __name__ == "__main__":
    main()