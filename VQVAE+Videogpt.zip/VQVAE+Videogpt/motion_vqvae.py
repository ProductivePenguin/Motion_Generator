import argparse
import pytorch_lightning as pl
import torch
import torch.nn as nn
import torch.nn.functional as F

class Codebook(nn.Module):
    def __init__(self, n_codes: int, embedding_dim: int):
        super().__init__()
        # 初始化可学习的 codebook （shape: [n_codes, embedding_dim]）
        self.register_buffer('embeddings', torch.randn(n_codes, embedding_dim))
        self.register_buffer('N', torch.zeros(n_codes))
        self.register_buffer('z_avg', self.embeddings.data.clone())
        self.n_codes = n_codes
        self.embedding_dim = embedding_dim
        self._need_init = True

    def _init_embeddings(self, z):
        self._need_init = False
        flat_inputs = z.flatten(2).transpose(1, 2)  # [B, H*W, C]
        B, N, C = flat_inputs.shape
        if N < self.n_codes:
            n_repeats = (self.n_codes + N - 1) // N
            flat_inputs = flat_inputs.repeat(1, n_repeats, 1)
        rand_idx = torch.randperm(flat_inputs.shape[1])[:self.n_codes]
        init_codes = flat_inputs[0, rand_idx, :]
        self.embeddings.data.copy_(init_codes)
        self.z_avg.data.copy_(init_codes)
        self.N.data.copy_(torch.ones(self.n_codes))

    def forward(self, z):
        if self._need_init and self.training:
            self._init_embeddings(z)
        B, C, H, W = z.shape
        flat_z = z.view(B, C, -1).transpose(1, 2)  # [B, H*W, C]
        # 计算每个位置到所有 code 的距离
        distances = (flat_z ** 2).sum(dim=-1, keepdim=True) \
                    - 2 * flat_z @ self.embeddings.t() \
                    + (self.embeddings.t() ** 2).sum(dim=0, keepdim=True)
        # 找离它最近的 codebook 索引
        encoding_indices = distances.argmin(dim=-1)  # [B, H*W]
        # 把它 reshape 回空间形状，作为 “离散码”
        encodings = encoding_indices.view(B, H, W)  # [B, H, W]

        # 用这些索引取出量化向量
        quantized = F.embedding(encoding_indices, self.embeddings)
        quantized = quantized.view(B, H, W, self.embedding_dim).permute(0, 3, 1, 2)

        # commitment loss
        commitment_loss = F.mse_loss(quantized.detach(), z)
        # straight‑through estimator
        quantized = z + (quantized - z).detach()

        # perplexity 计算
        with torch.no_grad():
            onehot = F.one_hot(encoding_indices, num_classes=self.n_codes).float()  # [B, H*W, n_codes]
            avg_probs = onehot.mean(dim=1).clamp(min=1e-10)
            ent = -torch.sum(avg_probs * torch.log(avg_probs), dim=1)
            perplexity = torch.exp(ent).mean()

        return {
            "encodings":       encodings,  # [B, H, W] 上每个位置的 codebook 索引
            "embeddings":      quantized,   # [B, C, H, W] 量化后的向量
            "commitment_loss": commitment_loss,
            "perplexity":      perplexity
        }

class MotionVQVAE(pl.LightningModule):
    def __init__(
        self,
        embedding_dim: int = 128,
        n_codes:       int = 1024,
        mv_channels:  int = 1,
        learning_rate: float = 3e-4,
        weight_decay:  float = 0.0,
    ):
        super().__init__()
        self.save_hyperparameters()

        self.input_proj  = nn.Conv2d(self.hparams.mv_channels, self.hparams.embedding_dim, kernel_size=1)
        self.codebook    = Codebook(self.hparams.n_codes, self.hparams.embedding_dim)
        self.output_proj = nn.Conv2d(self.hparams.embedding_dim, self.hparams.mv_channels, kernel_size=1)

    def forward(self, x):
        z = self.input_proj(x)
        vq = self.codebook(z)
        x_recon = self.output_proj(vq["embeddings"])
        # train_loss = MSE + commitment
        loss = F.mse_loss(x_recon, x) + vq["commitment_loss"]
        return loss, x_recon, vq

    def training_step(self, batch, batch_idx):
        x = batch["mv"]
        loss, x_recon, vq = self.forward(x)
        mse = F.mse_loss(x_recon, x)
        c_loss = vq["commitment_loss"]
        # 日志记录
        self.log("train_loss", loss,        prog_bar=True)
        self.log("mse_loss",   mse,         prog_bar=True)
        self.log("commitment_loss", c_loss, prog_bar=True)
        self.log("perplexity", vq["perplexity"], prog_bar=True)
        return loss

    def configure_optimizers(self):
        return torch.optim.Adam(
            self.parameters(),
            lr=self.hparams.learning_rate,
            weight_decay=self.hparams.weight_decay
        )

    @staticmethod
    def add_model_specific_args(parent_parser):
        group = parent_parser.add_argument_group("MotionVQVAE Args")
        group.add_argument('--embedding_dim', type=int,   default=128)
        group.add_argument('--n_codes',       type=int,   default=1024)
        group.add_argument('--mv_channels',   type=int,   default=1)
        group.add_argument('--learning_rate', type=float, default=3e-4)
        group.add_argument('--weight_decay',  type=float, default=0.0)
        return parent_parser
