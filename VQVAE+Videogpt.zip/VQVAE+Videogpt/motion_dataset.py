import os
import glob
import torch
from torch.utils.data import Dataset

class MotionVectorDatasetNew(Dataset):
    def __init__(self, root_dir, normalize=True, norm_factor=1.0):
        self.root_dir = root_dir
        self.normalize = normalize
        self.norm_factor = norm_factor
        pattern = os.path.join(root_dir, "*.txt")
        self.file_list = glob.glob(pattern)
        if not self.file_list:
            raise RuntimeError(f"在 {root_dir} 中未找到匹配 {pattern} 的文件")
        self.min_length = self._compute_global_min_length()
        if self.min_length <= 0:
            raise RuntimeError("未找到有效的向量长度")
        print(f"全局最短向量长度: {self.min_length}")

    def _compute_global_min_length(self):
        min_length = float('inf')
        for file in self.file_list:
            with open(file, 'r') as f:
                for line in f:
                    tokens = line.strip().split()
                    if tokens:
                        cur_len = len(tokens)
                        if cur_len < min_length:
                            min_length = cur_len
        return int(min_length) if min_length != float('inf') else 0

    def __len__(self):
        return len(self.file_list)

    def _parse_line(self, line):
        tokens = line.strip().split()
        vector = []
        for token in tokens:
            try:
                vector.append(float(token))
            except:
                continue
        return vector

    def _load_file(self, file_path):
        vectors = []
        with open(file_path, 'r') as f:
            for line in f:
                vec = self._parse_line(line)
                if vec:
                    vec = vec[:self.min_length]
                    vectors.append(vec)
        if not vectors:
            raise RuntimeError(f"{file_path} 中没有有效数据")
        tensor = torch.tensor(vectors, dtype=torch.float32)
        if self.normalize:
            tensor = tensor / self.norm_factor
        tensor = tensor.unsqueeze(0)
        return tensor

    def __getitem__(self, idx):
        file_path = self.file_list[idx]
        mv_tensor = self._load_file(file_path)
        return {"mv": mv_tensor, "file": os.path.basename(file_path)}

if __name__ == "__main__":
    dataset = MotionVectorDatasetNew(root_dir="./temporal_x", normalize=True, norm_factor=10.0)
    sample = dataset[0]
    print("文件名:", sample["file"])
    print("运动矢量张量形状:", sample["mv"].shape)
