import os
import glob
import torch
import torch.nn as nn
import torch.nn.functional as F
import pytorch_lightning as pl
from torch.utils.data import Dataset, DataLoader
from pytorch_lightning.cli import LightningCLI
from pytorch_lightning.callbacks import ModelCheckpoint, LearningRateMonitor
from torch.optim.lr_scheduler import OneCycleLR

class First96Dataset(Dataset):
    #读取每个 .txt 文件，将每行解析为浮点列表，只取前 first_n 个数字（小于时填0），最终输出形状 (1, H, first_n) 的 Tensor。
    def __init__(self, root_dir: str, first_n: int = 96, normalize: bool = True, norm_factor: float = 1.0):
        self.first_n = first_n
        self.normalize = normalize
        self.norm_factor = norm_factor
        pattern = os.path.join(root_dir, "*.txt")
        self.files = sorted(glob.glob(pattern))
        if not self.files:
            raise RuntimeError(f"在 {root_dir} 中未找到 .txt 文件")

    def __len__(self):
        return len(self.files)

    def __getitem__(self, idx):
        fp = self.files[idx]
        # 读所有行，解析浮点，截取/填充到 first_n
        rows = []
        with open(fp) as f:
            for line in f:
                vals = []
                for tok in line.strip().split():
                    try:
                        vals.append(float(tok))
                    except:
                        pass
                    if len(vals) >= self.first_n:
                        break
                if len(vals) < self.first_n:
                    vals += [0.0] * (self.first_n - len(vals))
                rows.append(vals)
        if not rows:
            raise RuntimeError(f"{fp} 无有效数据")
        mat = torch.tensor(rows, dtype=torch.float32)  # (H, first_n)
        if self.normalize:
            mat = mat / self.norm_factor
        return {"mv": mat.unsqueeze(0), "file": os.path.basename(fp)}  # (1, H, first_n)

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=1000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len).unsqueeze(1).float()
        div_term = torch.exp(torch.arange(0, d_model, 2).float() *
                             (-torch.log(torch.tensor(10000.0)) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe.unsqueeze(0))  # (1, max_len, d_model)

    def forward(self, x):
        # x: (B, L, D)
        return x + self.pe[:, :x.size(1), :]

class MotionVideoGPT(pl.LightningModule):
    def __init__(
        self,
        vqvae_checkpoint_override: str,
        hidden_dim: int = 576,
        heads: int = 4,
        layers: int = 8,
        dropout: float = 0.1,
        seq_len: int = 96,
        learning_rate: float = 5e-5,
        weight_decay: float = 1e-2,
        **kwargs
    ):
        super().__init__()
        self.save_hyperparameters()

        # 冻结加载 VQ-VAE
        from motion_vqvae import MotionVQVAE
        self.vqvae = MotionVQVAE.load_from_checkpoint(self.hparams.vqvae_checkpoint_override)
        for p in self.vqvae.parameters():
            p.requires_grad = False
        self.vqvae.eval()

        # 输入投影 & 位置编码
        vq_dim = self.vqvae.hparams.embedding_dim
        self.fc_in = nn.Linear(vq_dim, hidden_dim, bias=False)
        self.pos_enc = PositionalEncoding(hidden_dim, max_len=seq_len)
        self.drop = nn.Dropout(dropout)

        # TransformerEncoder + 因果 Mask
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim, nhead=heads, dropout=dropout, batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=layers)
        mask = torch.triu(torch.ones(seq_len, seq_len), diagonal=1).bool()
        self.register_buffer("mask", mask)

        # 输出投影
        n_codes = self.vqvae.hparams.n_codes
        self.fc_out = nn.Linear(hidden_dim, n_codes, bias=False)

    def forward(self, x, targets):
        h = self.fc_in(x)
        h = self.pos_enc(h)
        h = self.drop(h)
        h = self.transformer(h, mask=self.mask)
        logits = self.fc_out(h)
        return F.cross_entropy(logits.view(-1, logits.size(-1)), targets.view(-1))

    def training_step(self, batch, _):
        mv = batch["mv"]            # (B,1,H,seq_len)
        with torch.no_grad():
            _, _, vq = self.vqvae(mv)    # vq["encodings"]: (B, Hc, Wc)
            codes = vq["encodings"]
        emb   = self.vqvae.codebook.embeddings
        x_emb = emb[codes]              # (B,Hc,Wc,D)
        B, Hc, Wc, D = x_emb.shape
        seq   = Hc * Wc
        x_seq = x_emb.view(B, seq, D)
        y_seq = codes.view(B, seq)
        sl    = self.hparams.seq_len
        if seq >= sl:
            x_seq, y_seq = x_seq[:, :sl, :], y_seq[:, :sl]
        else:
            pad = sl - seq
            x_seq = F.pad(x_seq, (0,0,0,pad))
            y_seq = F.pad(y_seq, (0,pad), value=0)
        loss = self.forward(x_seq, y_seq)
        self.log("train_loss", loss, prog_bar=True)
        return loss

    def configure_optimizers(self):
        opt = torch.optim.AdamW(
            self.parameters(),
            lr=self.hparams.learning_rate,
            weight_decay=self.hparams.weight_decay
        )
        total_steps = self.trainer.estimated_stepping_batches
        sched = OneCycleLR(opt, max_lr=self.hparams.learning_rate,
                           total_steps=total_steps, pct_start=0.1,
                           anneal_strategy='linear')
        return [opt], [{'scheduler': sched, 'interval': 'step'}]

    @staticmethod
    def add_model_specific_args(parent):
        g = parent.add_argument_group("MotionVideoGPT")
        g.add_argument('--vqvae_checkpoint_override', type=str, required=True)
        g.add_argument('--hidden_dim', type=int, default=576)
        g.add_argument('--heads', type=int, default=4)
        g.add_argument('--layers', type=int, default=8)
        g.add_argument('--dropout', type=float, default=0.1)
        g.add_argument('--seq_len', type=int, default=96)
        g.add_argument('--learning_rate', type=float, default=5e-5)
        g.add_argument('--weight_decay', type=float, default=1e-2)
        return parent

class DataModule(pl.LightningDataModule):
    def __init__(self,
                 data_root: str,
                 seq_len: int = 96,
                 batch_size: int = 1,
                 num_workers: int = 4):
        super().__init__()
        self.data_root   = data_root
        self.seq_len     = seq_len
        self.batch_size  = batch_size
        self.num_workers = num_workers

    def setup(self, stage=None):
        self.dataset = First96Dataset(
            root_dir    = self.data_root,
            first_n     = self.seq_len,
            normalize   = True,
            norm_factor = 10.0
        )

    def train_dataloader(self):
        return DataLoader(
            self.dataset,
            batch_size         = self.batch_size,
            num_workers        = self.num_workers,
            shuffle            = True,
            persistent_workers = True,
        )

checkpoint_cb = ModelCheckpoint(
    save_last      = True,
    save_top_k     = 5,
    every_n_epochs = 1,
    filename       = "{epoch:02d}-{train_loss:.4f}",
    monitor        = "train_loss",
    mode           = "min",
)

lr_monitor = LearningRateMonitor(logging_interval='step')

if __name__ == "__main__":
    LightningCLI(
        model_class      = MotionVideoGPT,
        datamodule_class = DataModule,
        trainer_defaults = {
            "callbacks": [checkpoint_cb, lr_monitor],
            "precision": 16,
            "gradient_clip_val": 1.0,
            "log_every_n_steps": 10,
        },
    )
