import os
import sys
import argparse
import pytorch_lightning as pl
from pytorch_lightning.loggers import TensorBoardLogger
from pytorch_lightning.callbacks import ModelCheckpoint
from torch.utils.data import DataLoader
from motion_vqvae import MotionVQVAE
from motion_dataset import MotionVectorDatasetNew

class MotionDataModule(pl.LightningDataModule):
    def __init__(
        self,
        data_root:   str = "./temporal_x",
        batch_size:  int = 1,
        num_workers: int = 4,
        normalize:   bool = True,
        norm_factor: float = 10.0,
    ):
        super().__init__()
        self.data_root   = data_root
        self.batch_size  = batch_size
        self.num_workers = num_workers
        self.normalize   = normalize
        self.norm_factor = norm_factor

    def setup(self, stage=None):
        self.dataset = MotionVectorDatasetNew(
            root_dir    = self.data_root,
            normalize   = self.normalize,
            norm_factor = self.norm_factor,
        )

    def train_dataloader(self):
        return DataLoader(
            self.dataset,
            batch_size   = self.batch_size,
            num_workers  = self.num_workers,
            shuffle      = True,
        )

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="训练 MotionVQVAE")
    parser.add_argument('--seed',          type=int,   default=0,      help='随机种子')
    parser.add_argument('--accelerator',   type=str,   default='auto', help='加速方式 (auto, gpu, cpu)')
    parser.add_argument('--devices',       type=int,   default=1,      help='设备数量')
    parser.add_argument('--embedding_dim', type=int,   default=128,    help='嵌入维度')
    parser.add_argument('--n_codes',       type=int,   default=1024,   help='Codebook 大小')
    parser.add_argument('--mv_channels',   type=int,   default=1,      help='运动矢量通道数')
    parser.add_argument('--data_root',     type=str,   default='./temporal_x', help='数据根目录')
    parser.add_argument('--batch_size',    type=int,   default=1,      help='每批大小')
    parser.add_argument('--num_workers',   type=int,   default=4,      help='数据加载进程数')
    parser.add_argument('--normalize',     action='store_true',         help='是否归一化')
    parser.add_argument('--norm_factor',   type=float, default=10.0,   help='归一化因子')
    parser.add_argument('--max_epochs',    type=int,   default=100,    help='最大训练轮数')
    parser.add_argument('--lr',            type=float, default=3e-4,   help='学习率')
    parser.add_argument('--weight_decay',  type=float, default=0.0,    help='权重衰减')
    args = parser.parse_args()

    pl.seed_everything(args.seed)

    logger = TensorBoardLogger(save_dir="lightning_logs", name="VQVAE")
    ckpt_dir = os.path.join(logger.log_dir, "checkpoints")
    ckpt_cb = ModelCheckpoint(
        dirpath=ckpt_dir,
        filename="{epoch:02d}-{train_loss:.4f}",
        monitor="train_loss",
        mode="min",
        save_top_k=5,
        save_last=True,
        every_n_epochs=1,
        save_on_train_epoch_end=True,
    )

    dm = MotionDataModule(
        data_root   = args.data_root,
        batch_size  = args.batch_size,
        num_workers = args.num_workers,
        normalize   = args.normalize,
        norm_factor = args.norm_factor,
    )
    dm.setup()

    model = MotionVQVAE(
        embedding_dim = args.embedding_dim,
        n_codes       = args.n_codes,
        mv_channels   = args.mv_channels,
        learning_rate = args.lr,
        weight_decay  = args.weight_decay,
    )

    trainer = pl.Trainer(
        max_epochs  = args.max_epochs,
        accelerator = args.accelerator,
        devices     = args.devices,
        logger      = logger,
        callbacks   = [ckpt_cb],
    )
    trainer.fit(model, dm)
