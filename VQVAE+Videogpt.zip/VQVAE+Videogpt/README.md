# README

## 运行环境

 4070 Laptop

```
conda env create -f mv_env.yaml（训练环境）
```

```
conda env create -f videogpt_env.yaml（tensorboard监控环境）
```



## tensorboard监控训练

```
tensorboard --logdir lightning_logs（lightning_logs所在目录处）
```



## 将运动矢量拆分为水平、垂直运动矢量

```
python split_xy.py
```



## VQ-VAE训练

```
python train_motion_vqvae_cli.py --seed 0 --data_root ./文件名 --batch_size 1 --num_workers 4 --normalize --norm_factor 10.0 --max_epochs 100 --accelerator gpu --devices 1 --embedding_dim 256 --n_codes 1024 --mv_channels 1 --lr 3e-4 --weight_decay 0.0
```



## Videogpt训练

```
python train_motion_videogpt_fixed.py fit --data.data_root ./文件名 --data.seq_len 96 --data.batch_size 1 --data.num_workers 4 --model.vqvae_checkpoint_override ./vqvae路径 --model.hidden_dim 768 --model.heads 8 --model.layers 12 --model.dropout 0.1 --model.seq_len 96 --model.learning_rate 5e-5 --model.weight_decay 1e-2 --trainer.max_epochs 100 --trainer.precision 16 --trainer.log_every_n_steps 10
```



## VQ-VAE+Videogpt生成

```
python decode_motion_fixed.py --gpt_checkpoint ./videogpt路径 --vqvae_checkpoint_override ./vqvae路径 --gen_frames 30 --input_folder ./文件名 --output_folder ./输出文件名 --norm_factor 10.0 --temperature 1.0 
```



## 将生成的水平、垂直运动矢量合为运动矢量

```
python merge_xy.py
```



## 目前存在问题及改进方案

1.原本运动矢量是以x,y的形式存在，但是目前模型训练是将x,y的数据分别作为输入进行训练，后续可以考虑将x,y联合起来训练。

2.目前VQ-VAE、Videogpt的训练，只采用每行前96个数字训练，这是为了训练方便，没有运用到全部的数据，后续需要采用每一行的全部数据进行训练或者在采样运动矢量的时候固定每行的数字数量一致。

3.目前的n_codes、embedding_dim（codebook大小、维度）已经设置的很大了，但是perplexity还是很小（远小于n_codes的一半），只有40-60，可能是因为模型训练的输入把每个 .txt 文件当作一个样本，会使得数据规模太小，我后续考虑过利用每一行向量作为一个样本，但是训练会很困难，非常容易爆显存，这一点还没有解决，目前最佳解决方案还是先尝试测试已有的生成效果，然后再决定是否需要改进样本输入形式。

4.目前生成的数字，有一些行的生成只有0，并且其他行生成的数字种类非常少，不符合原本数据，尝试使用百分位归一化（利用第99%位数字进行归一化，目前是用10做归一化），vqvae的训练loss会降低，但是会影响videogpt的训练，原因未知，需要进一步改进。
